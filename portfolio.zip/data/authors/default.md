---
name: Manoj Kumar G K
shortname: Manoj
avatar: /static/avatar.jpg
occupation: Software Engineer
company: Commonwealth Bank
resume: /static/manoj_resume.pdf
email: manojkumar.g.k@outlook.com
linkedin: https://www.linkedin.com/in/manojkumargk
github: https://github.com/mannoj8861
---


