export type Maybe<T> = T | null;

export type Tuple<T> = [T, T];
