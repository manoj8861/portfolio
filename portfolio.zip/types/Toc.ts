export type Toc = {
  value: string;
  depth: number;
  url: string;
}[];
